-- MySQL dump 10.13  Distrib 8.0.30, for Win64 (x86_64)
--
-- Host: localhost    Database: orders
-- ------------------------------------------------------
-- Server version	8.0.30

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `orderdetails`
--

DROP TABLE IF EXISTS `orderdetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orderdetails` (
  `OrderId` int NOT NULL AUTO_INCREMENT,
  `CustId` int DEFAULT NULL,
  `VendorId` int DEFAULT NULL,
  `OrderName` varchar(30) DEFAULT NULL,
  `OrderDate` date NOT NULL,
  `price` decimal(9,2) DEFAULT NULL,
  `OrderStatus` enum('PLACED','CONFIRMED','DELIVERED') DEFAULT 'PLACED',
  PRIMARY KEY (`OrderId`),
  UNIQUE KEY `OrderName` (`OrderName`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orderdetails`
--

LOCK TABLES `orderdetails` WRITE;
/*!40000 ALTER TABLE `orderdetails` DISABLE KEYS */;
INSERT INTO `orderdetails` VALUES (1,1,1,'Track-Suit','2024-05-26',500.00,'CONFIRMED'),(2,2,2,'Chuidar','2024-03-11',999.00,'CONFIRMED'),(3,3,3,'Tshirt','2024-01-23',547.00,'CONFIRMED'),(4,4,4,'Saree','2024-04-01',700.00,'CONFIRMED'),(5,5,0,'Inner','2024-06-04',700.00,'CONFIRMED'),(6,6,0,'ark','2024-06-03',600.00,'CONFIRMED'),(7,7,0,'phone','2024-06-12',400.00,'CONFIRMED'),(8,1,0,'chees','2024-06-11',500.00,'CONFIRMED'),(9,0,0,'cheesee','2024-06-11',600.00,'CONFIRMED'),(10,8,0,'new','2024-06-13',200.00,'PLACED'),(11,9,0,'piz','2024-06-19',900.00,'PLACED');
/*!40000 ALTER TABLE `orderdetails` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-20 16:01:34
